var app_firebase={};
(function(){
	 // initialize
	  var config = {
	    apiKey: "AIzaSyA8o3qxzT8RSovx2VmwJN1oOblY0T9ff5s",
	    authDomain: "myfirebaseproject-fb133.firebaseapp.com",
	    databaseURL: "https://myfirebaseproject-fb133.firebaseio.com",
	    projectId: "myfirebaseproject-fb133",
	    storageBucket: "myfirebaseproject-fb133.appspot.com",
	    messagingSenderId: "99563451489",
	    appId: "1:99563451489:web:bc092493e88c271828a620",
	    measurementId: "G-DG2XJLT6LW"
	  };
	  // Initialize Firebase
	  firebase.initializeApp(config);
	  app_firebase=firebase;
	  function fnCreate(path,body,callBack){
		  app_firebase.database().ref(path).set(body,callBack);
		  
	  }
	  function fnUpdate(path,body,callBack){
		  app_firebase.database().ref(path).update(body,callBack);
		  
	  }
	  function fnDelete(path,callBack){
		  app_firebase.database().ref(path).remove(callBack);
		  
	  }
	  
	  function fnRead(path,successFn,errFn){
		  app_firebase.database().ref(path).once('value').then(successFn,errFn);
		  
	  }
	
	 app_firebase.databaseApi={
			create:fnCreate,
	 		read:fnRead,
	 		update:fnUpdate,
	 		delete:fnDelete
	 }
	
	
	
})()