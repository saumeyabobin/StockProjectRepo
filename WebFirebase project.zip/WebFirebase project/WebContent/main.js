var mainApp={};
(function(){
	var firebase=app_firebase;
	var uid=null;
	
	function msgHandler(err){
		
		if(!!err){
			console.log(err);
		}
		else{
			console.log("success")
		}
	}
	
	function fnCreate(){
		
		console.log("in create..");
		 var stk_sym = document.getElementById('stk_sym').value;

		 var ask_price = Number(document.getElementById('ask_price').value);
		 
		 var bid_price = Number(document.getElementById('bid_price').value);
		
		 var time=(document.getElementById('evnt_time').value).toString();
		
		 if(stk_sym==""||ask_price==""||bid_price==""||time==""){
			 alert("Please enter all the stock detail fields!!!")
		 }
		 else{
		 var path='stocks/'+stk_sym;
		 console.log("path"+path)
		 var data={
	    					stocksymbol:stk_sym,
	    					askprice:ask_price,
	    					bidprice:bid_price,
	    					time:time,
	    					trend:"UP"
	    			}
		
		
		//get the stk_sym present or not. if present update, Else say not found
	     //var path1='stocks/';//+stk_sym;
	     console.log(path);
	     app_firebase.database().ref('stocks/').child(stk_sym).once('value', function(snapshot) {
	    	    var exists = (snapshot.val() !== null);
	    	    console.log(snapshot.val());
	    	   
	    	    userExistsCallback(stk_sym, exists);
	    	  });
	     
	     function userExistsCallback(stk_sym, exists) {
	    	  if (exists) {
	    		  alert(stk_sym +" stock already present!!!");
	    		 
	    			
	    	  }
	    	  else{
	    		  console.log(data);
	    		  app_firebase.databaseApi.create(path,data,msgHandler);
	    		  alert("The stock created successfully...");
	    	  }
		}
			
		
	 }
	}
	
	function fnUpdate(){
		console.log("in update..");
		 var stk_sym = document.getElementById('stk_sym').value;
		 var ask_price = Number(document.getElementById('ask_price').value);
		 var bid_price = Number(document.getElementById('bid_price').value);
		 var time=document.getElementById('evnt_time').value;
		 var marketPrice=(ask_price+bid_price)/2;
		 var trend;
		 if(stk_sym==""||ask_price==""||bid_price==""||time==""){
			 alert("Please enter all the stock detail fields!!!")
		 }
		 else{
		 //get the stk_sym present or not. if present update, Else say not found
	     var path='stocks/';//+stk_sym;
	     console.log(path);
	     app_firebase.database().ref(path).child(stk_sym).once('value', function(snapshot) {
	    	    var exists = (snapshot.val() !== null);
	    	    console.log(snapshot.val());
	    	   
	    	    userExistsCallback(stk_sym,snapshot.val(),marketPrice, exists);
	    	  });
		
	     function userExistsCallback(stk_sym,oldVal,marketPrice, exists) {
	    	  if (exists) {
		    	    alert('stock_symol => ' + stk_sym + ' exists..Updating details...');
		    	    var old_askPrice=oldVal.askprice;
		    	    var old_bidPrice=oldVal.bidprice;
		    	    old_mktPrice=(old_askPrice+old_bidPrice)/2;
		    	    console.log("old_mktPrice:"+old_mktPrice +"marketPrice:"+marketPrice);
		    	    if(marketPrice>=old_mktPrice){ //set the trend
		    	    	trend="UP";
		    	    }
		    	    else{
		    	    	trend="DOWN";
		    	    }
		    	    var data={
							stocksymbol:stk_sym,
							askprice:ask_price,
							bidprice:bid_price,
							time:time,
							trend:trend
		    	    }
		    	    //update the data
		    	    app_firebase.databaseApi.update('stocks/'+stk_sym,data,msgHandler);
		    	    alert('stock_symol =>' + stk_sym + ' updated successfully...');
    	    
	    	  } else {
	    	    alert('stock_symol =>' + stk_sym + ' does not exist!');
	    	  }
	    	}
		 
		 
		 
		 }
	}
	function fnDelete(){
		 var stk_sym = document.getElementById('stk_sym').value;
		 if(stk_sym==""){
			 alert("Please enter the stock symbol to delete...")
		 }
		 else{
			 app_firebase.database().ref('stocks/').child(stk_sym).once('value', function(snapshot) {
		    	    var exists = (snapshot.val() !== null);
		    	    console.log(snapshot.val());
		    	   
		    	    userExistsCallback(stk_sym,exists);
		    	  });
			 function userExistsCallback(stk_sym,exists){
				 if (exists) {
					 app_firebase.databaseApi.delete('stocks/'+stk_sym,msgHandler);
					 alert('stock_symol =>' + stk_sym + ' deleted successfully!');
				 }
				 else{
					 alert('stock_symol =>' + stk_sym + ' does not exist!');
				 }
				 
			 }
			
			 
			
		}
	}
	
	function fnRead(){
		console.log("in read..");
		 var stk_sym = document.getElementById('stk_sym').value;
		 
		 var path='stocks/';//+stk_sym;
		 console.log(path);
		app_firebase.databaseApi.read(path,successfn,msgHandler);
		function successfn(snapShot){
			 if(!!snapShot){
			 	 console.log(snapShot.val());
			 	 //alert("values are:"+snapShot.val());
			 }else{
				 console.log("No Data Found");
			 }
		 }
		 
	}
	
	mainApp.create=fnCreate;
	mainApp.read=fnRead;
	mainApp.update=fnUpdate;
	mainApp.delete=fnDelete;
	
	
})()