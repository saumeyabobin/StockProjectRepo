import { Subscription, Observable } from 'rxjs';
import { Component } from '@angular/core';
import {AngularFireDatabase,AngularFireList} from 'angularfire2/database';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'stockproject';
  stock$:Observable<any>;
  stock: any[];
  
  //subscription: Subscription;
  //stockValue: any[];
  //trend: String;
  constructor(db: AngularFireDatabase){
    this.stock$=db.list('/stocks').valueChanges()
    //this.subscription=db.list('/stock')
    //.valueChanges().subscribe(stock=> {
     // this.stock=stock;
      console.log(this.stock$);
      
    };

    
  
}
